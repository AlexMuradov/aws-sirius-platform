package D

import "github.com/onsi/ginkgo/v2/integration/_fixtures/watch_fixture/C"

func DoIt() string {
	return C.DoIt()
}
