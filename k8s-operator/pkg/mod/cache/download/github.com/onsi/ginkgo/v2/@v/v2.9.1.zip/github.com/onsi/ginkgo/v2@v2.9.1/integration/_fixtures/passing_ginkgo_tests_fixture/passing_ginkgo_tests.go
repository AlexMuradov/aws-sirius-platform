package passing_ginkgo_tests

func StringIdentity(a string) string {
	return a
}

func IntegerIdentity(a int) int {
	return a
}
